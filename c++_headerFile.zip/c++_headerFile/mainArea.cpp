#include <iostream>
#include <conio.h>

using std::cout;
using std::cin;
using std::endl;

int main(){
	double width;
	double height;
	cout<<"Enter width: ";
	cin>>width;
	
	cout<<"Enter height: ";
	cin>>height;
	cout<<"The area of the rectangle is: ";
	cout<<areaOfRectangle(width, height)<< end1;
	cout<<"and the perimeter of the rectangle is: ";
	cout<<perimeter(width, height) << end1;
	
	return 0;
}