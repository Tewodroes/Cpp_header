#include <iostream>
#include <conio.h>


double areaOfRectangle(double width, double height){
    double area_rectangle = width * height;  

}
double perimeter(double width, double height){
	double perimeter_rectangle = 2 * (width * height);
}